<?php
require_once ('link.php');
$username_err = "";
$UID = $_POST['UID'];
$PID = $_POST['PID'];
$PRate = $_POST['PRate'];


if($UID>31 || $PID>60 || $PRate>5){
    $result_p = FALSE;
    }
    else{
    // Prepare a select statement
    $query_p = "INSERT INTO `RateforProduct` (`UId`,`PId`,`PRate`) VALUES ($UID, $PID, $PRate);";
    $result_p = $conn->query($query_p);}



?>

<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GoodSearch</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
  </head>
    <body>
    <header>
      <h1>GoodSearch</h1>
    </header>
    <nav>
        <ul>
          <li>
            <a href="index.html"><h3>About</h3></a>
          </li>
          <li>
            <a href="query.html"><h3>query</h3></a>
          </li>
          <li>
            <a href="db.html"><h3>database</h3></a>
          </li>
          <li>
            <a class="active" ,href="#"><h3>insert</h3></a>
          </li>
          <li>
            <a href="search.html"><h3>search</h3></a>
          </li>
        </ul>
      </nav>
      <article>

      <h3><?php
      if ($result_p === TRUE){
        echo "Thanks for your feedback!";
      }
      else{
          echo "Invalid input";
      }
      ?>
      </h3>

        </tr>

            
        </table>
            </article>
    </body>
</html>