<?php
require_once ('link.php');

$PName = $_POST['PName'];


$query = sprintf("SELECT Product.Pname, Product.PDescription, ROUND(avg(RateforProduct.Prate),3), ROUND(avg(Mrate),3), Product.Pid, Market.Mname, Market.Mlocation, Market.Mphone
FROM Product, RateforProduct, Market, RateforMarket
WHERE Product.Pid = RateforProduct.Pid AND Product.Mid = Market.Mid AND Product.PName='%s' AND Market.Mid = RateforMarket.Mid
GROUP BY Product.Pid;",mysqli_real_escape_string($conn,$PName));
$result = $conn->query($query)or die( mysqli_error($conn));

?>


<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GoodSearch</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
  </head>
    <body>
    <header>
      <h1>GoodSearch</h1>
    </header>
    <section>
      <nav>
        <ul>
          <li>
            <a href="index.html"><h3>About</h3></a>
          </li>
          <li>
            <a class="active" ,href="#"><h3>query</h3></a>
          </li>
          <li>
            <a href="db.html"><h3>database</h3></a>
          </li>
          <li>
            <a href="insert.html"><h3>insert</h3></a>
          </li>
          <li>
            <a href="search.html"><h3>search</h3></a>
          </li>
        </ul>
      </nav>
      <article>
          
        <table>
        <tr>
            
            <th>Product Name</th>
            <th>PDescription</th>
            <th>Product Avg Rating</th>
            <th>Market Name</th>
            <th>Market Avg Rating</th>
            <th>Market Location</th>
            <th>Market Phone</th>
        </tr>
            <?php while ($row = mysqli_fetch_array($result)): ?>
                <?php $PName = $row['Pname']; ?>
                <?php $Prate = $row['ROUND(avg(RateforProduct.Prate),3)']; ?>
                <?php $PDescrption = $row['PDescription']; ?>
                <?php $MName = $row['Mname']; ?>
                <?php $Mrate = $row['ROUND(avg(Mrate),3)']; ?>
                <?php $Mloc = $row['Mlocation']; ?>
                <?php $Mphone = $row['Mphone']; ?>
                
                <tr>
            

                    <td><?php echo $PName; ?></td>
                    <td><?php echo $PDescrption; ?></td>

                    <td><?php echo $Prate; ?></td>

                    <td><?php echo $MName; ?></td>
                    <td><?php echo $Mrate; ?></td>

                    <td><?php echo $Mloc; ?></td>

                    <td><?php echo $Mphone; ?></td>
                </tr>


            <?php endwhile; ?>
        </table>
      </article>
    </section>
  </body>
</html>