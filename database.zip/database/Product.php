<?php
require_once ('../link.php');


$query = "SELECT * FROM 261project.Product";
$result = $conn->query($query);


?>


<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GoodSearch</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
  </head>
    <body>
    <header>
      <h1>GoodSearch</h1>
    </header>
    <nav>
        <ul>
          <li>
            <a href="index.html"><h3>About</h3></a>
          </li>
          <li>
            <a href="query.html"><h3>query</h3></a>
          </li>
          <li>
            <a class="active" ,href="#"><h3>database</h3></a>
          </li>
          <li>
            <a href="insert.html"><h3>insert</h3></a>
          </li>
          <li>
            <a href="search.html"><h3>search</h3></a>
          </li>
        </ul>
      </nav>
      <article>
          <style>table, th, td {
             border: 1px solid;
             }
             th, td {
  border-bottom: 1px solid #ddd;
}

</style>
        <table style="width:100%">
        <tr>
            <th>Product ID</th>
            <th>Market ID</th>
            <th>Product Name</th>
            <th>Product Description</th>
            <th>Price</th>
        </tr>
            <?php while ($row = mysqli_fetch_array($result)): ?>
                <?php $Pid = $row['PID']; ?>
                <?php $Mid = $row['MID']; ?>
                <?php $PName = $row['PName']; ?>
                <?php $PDescription = $row['PDescription']; ?>
                <?php $Price = $row['Price']; ?>
                <tr>
                    <td><?php echo $Pid; ?></td>
                    <td><?php echo $Mid; ?></td>
                    <td><?php echo $PName; ?></td>
                    <td><?php echo $PDescription; ?></td>
                    <td><?php echo $Price; ?></td>
                </tr>

            <?php endwhile; ?>
        </table>
            </article>
    </body>
</html>