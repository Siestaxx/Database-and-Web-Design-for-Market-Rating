<?php
require_once ('../link.php');
$query = "SELECT * FROM 261project.Market";
$result = $conn->query($query);

?>


<html>
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GoodSearch</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
  </head>
    <body>
    <header>
      <h1>GoodSearch</h1>
    </header>
    <nav>
        <ul>
          <li>
            <a href="index.html"><h3>About</h3></a>
          </li>
          <li>
            <a href="query.html"><h3>query</h3></a>
          </li>
          <li>
            <a class="active" ,href="#"><h3>database</h3></a>
          </li>
          <li>
            <a href="insert.html"><h3>insert</h3></a>
          </li>
          <li>
            <a href="search.html"><h3>search</h3></a>
          </li>
        </ul>
      </nav>
      <article>
      <style>table, th, td {
             border: 1px solid;
             }
             th, td {
  border-bottom: 1px solid #ddd;
}

</style>
        <table style="width:100%">

        <tr>
            <th>Market ID</th>
            <th>Market Name</th>
            <th>Market Location</th>
            <th>Market Phone</th>
        </tr>
            <?php while ($row = mysqli_fetch_array($result)): ?>
                <?php $Mid = $row['MID']; ?>
                <?php $MName = $row['MName']; ?>
                <?php $MLocation = $row['MLocation']; ?>
                <?php $MPhone = $row['MPhone']; ?>
                <tr>
                    <td><?php echo $Mid; ?></td>
                    <td><?php echo $MName; ?></td>
                    <td><?php echo $MLocation; ?></td>
                    <td><?php echo $MPhone; ?></td>
                </tr>

            <?php endwhile; ?>
        </table>
            </article>
    </body>
</html>